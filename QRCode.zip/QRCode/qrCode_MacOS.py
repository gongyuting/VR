import qrcode
img=qrcode.make("http://9.234.85.107:8000")
img.save("qrCode.jpg")
