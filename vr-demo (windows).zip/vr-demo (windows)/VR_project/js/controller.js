app.config(['$httpProvider', function($httpProvider){
    $httpProvider.interceptors.push(['$q','$rootScope',function($q,$rootScope){
        return {
            'request': function(config){
                $rootScope.loading = true;
                return $q.resolve(config);
            },
            'response': function(response){
                $rootScope.loading = false;
                return $q.resolve(response);
            },
            'requestError':function(rejection){
                $rootScope.loading = false;
                return $q.reject(rejection);
            },
            'responseError':function(rejection){
                $rootScope.loading = false;
                return $q.reject(rejection);
            }
        }
    }]);
}]);


app.controller('MainCtrl', function($scope,$rootScope,$state) {
    $("#showUploadPic").css("display","block");
    $('#ajaxFrom').attr('action','https://gateway-a.watsonplatform.net/visual-recognition/api/v3/classify?api_key=420850fed113a1250fa90afcb5975b8ac23ed2c6&version=2018-05-07');
    fileSelectedFlag = false;
	var windowHeight = window.innerHeight;
    $("body").css("height",windowHeight+"px");
    $(".bigBorderArea").css("height",windowHeight*0.98*0.85+"px");
    //$(".bigBorderArea").css("height",windowHeight*0.98*0.85+"px");
	// $scope.picHeight = windowHeight * 0.8 - $('.textClass').height()- 25*3 +"px";
    $scope.picHeight = windowHeight * 0.98 * 0.85 - 67- 40 - 30 +"px";
    $scope.picWidth = (windowHeight * 0.8 - $('.textClass').height()- 25*3)*4/3 +"px";

    $(document).ready(function() {
        var options = {
            target: '#testPic',
            //iframe: true,
            error: showError,
            success:  showResponse
        };
        $('#ajaxFromBtn').on('click', Myreport);
    });

    function Myreport() {

        var xhr = new XMLHttpRequest();
        xhr.responseType = 'blob';

        xhr.open('GET', 'http://localhost:3000/test', true);

        xhr.onreadystatechange = function(e) {
            if (this.readyState == 4 && this.status == 200) {
                var urlCreator = window.URL || window.webkitURL;
                var imageUrl = urlCreator.createObjectURL(this.response);
                document.querySelector("#testPic").src = imageUrl;
                image = imageUrl;

                $('#showDashedBorder').css("display","none");
                $('#showUploadPic').css("display","block");
                fileSelectedFlag = true;

                imgBlob = this.response;
                uploadImg(imgBlob);
                return;
            }
        };

        xhr.onerror = function(e) {
            console.log(e.message);
        } 

        xhr.send();
    }

    function uploadImg(imgBlob) {
  
        $('.flyover').css("display","block");

        var data = new FormData();
        data.append('owners', 'me');
        data.append('threshold', 0);
        data.append('images_file', imgBlob);

        $.ajax({
            url :  $('#ajaxFrom').attr('action'),
            type:'post',
            data: data,
            contentType: false,
            processData: false,
            success: showResponse,    
            error: showError
        });

        return false;
    }

    function showError(xhr, statusText, error) {
        $('.flyover').css("display","none");
        alert(statusText + " " + error);
    }
    function showResponse(responseText, statusText, xhr, $form) {
        $('.flyover').css("display","block");
        // alert(xhr.responseText+"=="+$form.attr("method")+'status: ' + statusText + '\n\nresponseText: \n' + responseText);
        console.log(xhr.responseText);
        var result = JSON.parse(xhr.responseText);
        if(result.images[0].classifiers[0].classes.length == 0){
            alert("この写真は認識する事ができません。他の写真を選択して下さい。");
        }else{
            $state.go("result",{"res":result});
        }
    }

});

app.controller('ResultCtrl', function($scope,$state,$stateParams) {
    if(!$stateParams.res){
        $state.go("main");
        return
    }

    $scope.langArray_model = {"JPModern":"ジャパニーズモダン","Country":"クラシック・カントリー","Natural":"ナチュラルモダン","Stylish":"スタイリッシュモダン"};
    
    var resArray = $stateParams.res.images[0].classifiers
    var resArray_model = null;
   

    for (var i = resArray.length - 1; i >= 0; i--) {
        if (resArray_model != null) {
            break;
        }

        if (resArray [i].classifier_id == "stylenonegative_6847099") {
            if (resArray_model == null) {
                resArray_model = resArray [i].classes;

            }
        } 

    }

    resArray_model.sort(function (x,y) {
        return y.score-x.score;
    });
    if(resArray_model.length >4){
        resArray_model = resArray_model.slice(0,2);
    }

    

    $scope.resultArray_model = resArray_model;
   
    //$scope.sampleArray = resArray.slice(1);
    $scope.currentTypeName_model = $scope.langArray_model[$scope.resultArray_model [0].class];



    function setExamplePicModel(model) {
        $scope.pic1_src = "sample/"+model+"/"+model+"01.jpg";
        $scope.pic2_src = "sample/"+model+"/"+model+"02.jpg";
        $scope.pic3_src = "sample/"+model+"/"+model+"03.jpg";
        $scope.pic4_src = "sample/"+model+"/"+model+"04.jpg";
    }
   
    $scope.modelVal = $scope.resultArray_model [0].class;
    
    setExamplePicModel($scope.modelVal);

    var windowHeight = window.innerHeight;
    $(".body").css("height",windowHeight+"px");
    //$(".bigBorderArea").css("height",windowHeight*0.98*0.85+"px");
    //$(".bigBorderArea").css("height",windowHeight*1.65+"px");
    $(".bigBorderArea").css("height",windowHeight*0.88+"px");
    $(".resultContentHeight").css("height",windowHeight*1.00*0.92-window.innerWidth*0.02-72+"px");
    document.getElementById('testImage').src = image;

  

    $scope.clickBtnModel = function (val) {
        $scope.modelVal = val.class;
        setExamplePicModel(val.class,$scope.modelVal);
        $scope.currentTypeName_model = $scope.langArray_model[val.class];

    }

	$scope.goBack = function(){
	    $state.go("main");
    }


    $scope.legend = ['部屋のスタイル'];  
    //$scope.item = ['ジャパニーズモダン', 'クラシック・カントリー', 'ナチュラルモダン', 'スタイリッシュモダン'];  
   
 


    var jp = 0;
    var stylish=0;
    var natural=0;
    var country=0;
    var mixpercentage = $scope.resultArray_model[0].score;
    $scope.mixpercentage1=(mixpercentage*100).toFixed(1);

    //コメント
    var jpComment = "シンプルで伝統的なものを好みます。温もりを感じさせるシンプルなデザインのものを好む傾向があります。男性は特にこの傾向が強いです。"
    var stylishComment = "あなたはスタイリッシュで、流行に敏感な人です。現代的で洗練されたデザインを追い求める傾向があります。"
    var naturalComment = "あなたは常に自由でありたい人です。エレガントでありながら自然を感じさせるデザインを好む傾向があります。"
    var countryComment = "あなたは自然に触れる事の好きな人です。穏やかで、落ち着いた感じのデザインを好む傾向が強いです。"
    var comment="";

    for (var i = 0; i <= 1; i++) {
        
        if($scope.resultArray_model[i].class=="JPModern"){
            comment= comment+"\n"+jpComment;
        }else if($scope.resultArray_model[i].class=="Stylish"){
            comment= comment+"\n"+stylishComment;
        }else if($scope.resultArray_model[i].class=="Natural"){
            comment= comment+"\n"+naturalComment;
        }else if($scope.resultArray_model[i].class=="Country"){
            comment= comment+" \n "+countryComment;
        }
    }
   
    $scope.mixComment = comment
    

    for (var i = $scope.resultArray_model.length - 1; i >= 0; i--) {
        if($scope.resultArray_model[i].class=="JPModern"){
            jp = $scope.resultArray_model[i].score;
        }
        else if($scope.resultArray_model[i].class=="Stylish"){
            stylish = $scope.resultArray_model[i].score;
         }
        else if($scope.resultArray_model[i].class=="Natural"){
            natural = $scope.resultArray_model[i].score;
         }
         else if($scope.resultArray_model[i].class=="Country"){
            country = $scope.resultArray_model[i].score;
         }

    }
    $scope.item = ['ジャパニーズモダン   '+(jp*100).toFixed(1)+"%",'スタイリッシュモダン    '+(stylish*100).toFixed(1)+"%",'ナチュラルモダン    '+(natural*100).toFixed(1)+"%",'クラシック・カントリー     '+(country*100).toFixed(1)+"%"];  
    $scope.max = [1,1,1,1];  
  
    $scope.data = [  
        [jp, stylish, natural, country]  ,
      
     ];  
       
});
          
 
app.directive('radar', function() { 
    return {  
        scope: {  
            id: "@",  
            legend: "=",  
            item: "=",  
            max: "=",  
            data: "="  
        },  
        restrict: 'E',  
        template: '<div style="height:400px"></div>',  
        replace: true,  
        link: function($scope, element, attrs, controller) {  
            var option = {  

                tooltip: {  
                    trigger: 'axis'  
                },  
                legend: {  
                    orient: 'vertical',  
                    x: 'right',  
                    y: 'bottom',  
                    data: $scope.legend  
                },  
                gridLines: {
                    color: '#800000',
                   zeroLineColor: '#800000'
                 },

                // custom: {
                // fontColor: "#FFF0F5",
                // color: "#FFF0F5"
                //  },
                // polar: [{  
                           
                //     indicator: function(){  
                //         var indicator = [];  
                //         for(var i=0;i<$scope.item.length;i++){  
                //             var item = {  
                //                 text: $scope.item[i],  
                //                 max: $scope.max[i], //设置最大值  
                            
                                
                //             };  


                //             indicator.push(item);  
                //         };  
                //         return indicator;  
                //     }()  
                // }],  

                radar: {
                            // shape: 'circle',
                            name: {
                                textStyle: {
                                    color: 'blue',
                                    // backgroundColor: '#999',
                                    borderRadius: 3,
                                    padding: [3, 5]
                               }
                            },
                            indicator: function(){  
                                var indicator = [];  
                                for(var i=0;i<$scope.item.length;i++){  
                                    var item = {  
                                        text: $scope.item[i],  
                                        max: $scope.max[i] //设置最大值  
                                    };  
                                    indicator.push(item);  
                                };  
                                return indicator;  
                            }()
                        }, 

                series: [{  
                    type: 'radar',  
                    data: function(){  
                        var data = [];  
                        for(var i=0;i<$scope.legend.length;i++){  
                            var item = {  
                                name: $scope.legend[i],  
                                value: $scope.data[i]  
                            };  
                            data.push(item);  
                        }  
                        return data;  
                    }()  

                }]  
            };  
  
            var myChart = echarts.init(document.getElementById($scope.id),'macarons');  
            myChart.setOption(option);  
        }  
    };  
}); 
