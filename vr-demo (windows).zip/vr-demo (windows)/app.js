
var express = require('express');
var app = express();
var http = require('http');

app.use(express.static('VR_project'));
app.use(express.static('/app/upload/'));

app.get('/', function (req, res) {
  res.send('Hello World!');
});

app.get('/test', function (req, res) {

    var opts = {
        hostname: 'localhost',
        port:8000,
        path: '/test_picture',
        method: 'GET'
    };

    var routeReq = http.request(opts, function(result) {

        let body = [];

        result.on('data', function (chunk) {
            body.push(chunk);
        }).on('end', function() {
            res.header('Content-Type', 'application/octet-stream')
            res.end(Buffer.concat(body));
        });
    });

    routeReq.write('');
    routeReq.end();
});

app.listen(3000, function () {
  console.log('Example app listening on port 3000!');
});
