
// function selectImage(file) {
//     $('#ajaxFrom').attr('action','http://localhost:8000');
//     fileSelectedFlag = false;
//     $('#ajaxFrom').submit(function() {
//         if(!fileSelectedFlag){
//             alert("ファイルを選択して下さい。");
//             return false;
//         }
//         $('.flyover').css("display","block");
//         $(this).ajaxSubmit(options);
//         return false;
//     });

// }


function Myreport() {

    var xhr = new XMLHttpRequest();
    xhr.responseType = 'blob';

    xhr.open('GET', 'http://localhost:3000/test', true);

    xhr.onreadystatechange = function(e) {
        if (this.readyState == 4 && this.status == 200) {
            var urlCreator = window.URL || window.webkitURL;
            var imageUrl = urlCreator.createObjectURL(this.response);
            document.querySelector("#testPic").src = imageUrl;
            image = imageUrl;

            $('#showDashedBorder').css("display","none");
            $('#showUploadPic').css("display","block");
            fileSelectedFlag = true;

            imgBlob = this.response;
            $('#ajaxFromBtn').click();
        }
    };

    xhr.onerror = function(e) {
        console.log(e.message);
    } 

    xhr.send();
}