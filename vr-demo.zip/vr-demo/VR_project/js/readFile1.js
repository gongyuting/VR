var image = '';
function selectImage(file) {
    if (!file.files || !file.files[0]) {
        return;
    }
    var reader = new FileReader();
    reader.onload = function (evt) {
        fileSelectedFlag = true;
        $('#showDashedBorder').css("display","none");
        $('#showUploadPic').css("display","block");
        document.getElementById('testPic').src = evt.target.result;
        image = evt.target.result;
    }
    reader.readAsDataURL(file.files[0]);
}
