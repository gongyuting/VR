var app = angular.module('app', ['ui.router']);
app.config(function($stateProvider, $urlRouterProvider) {

    $stateProvider
        .state('main',{
            url:'/main',
            templateUrl: 'template/main.html',
            controller: 'MainCtrl'
        })

        .state('result', {
            url: '/result',
            templateUrl: 'template/result.html',
            controller: 'ResultCtrl',
            params: {res:null},
        });

    // if none of the above states are matched, use this as the fallback
    $urlRouterProvider.otherwise('/main');

});
